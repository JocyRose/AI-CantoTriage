from __future__ import annotations

import ast
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

# 使用项目内依赖运行，避免调用用户目录中可能不兼容的 Python 包。
PROJECT_DIR = Path(__file__).resolve().parents[1]
DEPS_DIR = PROJECT_DIR / "runtime" / "python_deps"
BASE_MODEL_ROOT = PROJECT_DIR / "基础模型"
INPUT_FILE = (
    PROJECT_DIR
    / "数据集"
    / "LCMDC_约44万条"
    / "训练数据_428条"
    / "测试_99条"
    / "输入_99条"
    / "输入_99条.jsonl"
)
OUTPUT_FILE = PROJECT_DIR / "试微调" / "对照组结果.json"

if __name__ == "__main__" and not sys.flags.no_site:
    raise SystemExit(
        subprocess.call(
            [sys.executable, "-S", str(Path(__file__).resolve()), *sys.argv[1:]]
        )
    )

if not (DEPS_DIR / "transformers" / "__init__.py").is_file():
    raise SystemExit(f"项目推理依赖缺失：{DEPS_DIR}")

import site

site.addsitedir(str(DEPS_DIR))
sys.path = [str(DEPS_DIR)] + [p for p in sys.path if p != str(DEPS_DIR)]


DEPARTMENTS = [
    "腫瘤科",
    "整形美容科",
    "康復醫學科",
    "心理科",
    "兒科",
    "婦產科",
    "傳染科",
    "皮膚性病科",
    "輔助檢查科",
    "內科",
    "外科",
    "五官科",
    "營養保健科",
    "中醫科",
    "急診科",
]

SYSTEM_PROMPT = f"""你是粤语 AI 语音导诊助手。请根据患者提供的粤语文字和结构化信息，输出粤语文字的严格 JSON。

只能从以下 15 个科室中选择一个或多个作为“建議科室”：
{json.dumps(DEPARTMENTS, ensure_ascii=False)}

输出格式必须是一个 JSON 对象，不要输出 Markdown 代码块、解释文字或思考过程：
{{
  "分流動作": "推薦科室/建議盡快就醫/建議立即急診",
  "建議科室": ["內科"],
  "症狀整理": "用粤语文字简洁整理患者症状",
  "簡短依據": {{
    "說明": "用粤语文字說明推荐依据",
    "事實編號": ["S1"]
  }},
  "緊急程度": {{
    "評估狀態": "未作分級/已作初步分級",
    "等級": "普通/尽快/急诊"
  }},
  "判斷限制": "用粤语文字說明信息不足和不能确诊的限制"
}}

要求：
1. 所有自然语言字段使用粤语文字；
2. “建議科室”必须是上述 15 个科室中的一个或多个，不能创造新科室；
3. “建議科室”必须是 JSON 数组；
4. 不要把患者自称的疾病当成已确诊；
5. 如果出现胸痛、呼吸困难、意识异常、严重出血、突发偏瘫等危险信号，应选择“急診科”，并明确建議立即急診；
6. 只输出 JSON 对象。"""


def find_model_dir() -> Path:
    """兼容“基础模型”目录下直接放模型或放在唯一子目录的结构。"""
    if (BASE_MODEL_ROOT / "config.json").is_file():
        return BASE_MODEL_ROOT

    candidates = sorted(
        p for p in BASE_MODEL_ROOT.iterdir() if p.is_dir() and (p / "config.json").is_file()
    )
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise FileNotFoundError(f"基础模型目录中没有找到 config.json：{BASE_MODEL_ROOT}")
    raise RuntimeError(
        "基础模型目录下发现多个模型，请保留一个模型或在脚本中明确指定："
        + ", ".join(str(p) for p in candidates)
    )


def load_model() -> tuple[Any, Any, Path]:
    global torch
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    model_dir = find_model_dir()
    print(f"正在加载基础模型：{model_dir}", flush=True)
    print("当前使用项目内推理依赖；CPU 推理可能需要较长时间。", flush=True)

    tokenizer = AutoTokenizer.from_pretrained(
        str(model_dir), local_files_only=True
    )
    model = AutoModelForCausalLM.from_pretrained(
        str(model_dir),
        dtype="auto",
        device_map="auto",
        low_cpu_mem_usage=True,
        local_files_only=True,
    )
    model.eval()
    return tokenizer, model, model_dir


def make_prompt(record: dict[str, Any]) -> str:
    input_data = record.get("input", record)
    return (
        "请根据以下患者资料完成粤语文字导诊，并严格按照系统要求只输出 JSON：\n"
        + json.dumps(input_data, ensure_ascii=False)
    )


def extract_json(text: str) -> Any | None:
    """从模型输出中提取 JSON；不做二次生成或自动修复。"""
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    decoder = json.JSONDecoder()
    for index, char in enumerate(cleaned):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(cleaned[index:])
            return value
        except json.JSONDecodeError:
            continue
    return None


def generate(tokenizer: Any, model: Any, record: dict[str, Any]) -> str:
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": make_prompt(record)},
    ]
    text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    inputs = tokenizer(text, return_tensors="pt")
    input_device = next(model.parameters()).device
    inputs = {key: value.to(input_device) for key, value in inputs.items()}

    with torch.inference_mode():
        generated_ids = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )

    new_ids = generated_ids[0][inputs["input_ids"].shape[1] :]
    result = tokenizer.decode(new_ids, skip_special_tokens=True).strip()
    if "</think>" in result:
        result = result.rsplit("</think>", 1)[-1].strip()
    return result


def load_records() -> list[dict[str, Any]]:
    if not INPUT_FILE.is_file():
        raise FileNotFoundError(f"测试集输入文件不存在：{INPUT_FILE}")
    records = []
    with INPUT_FILE.open("r", encoding="utf-8-sig") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"第 {line_number} 行不是合法 JSON：{exc}") from exc
    return records


def main() -> None:
    if "--check" in sys.argv[1:]:
        ast.parse(Path(__file__).read_text(encoding="utf-8"))
        print("脚本语法检查通过。")
        print(f"本地模型：{find_model_dir()}")
        print(f"测试输入条数：{len(load_records())}；候选科室：{len(DEPARTMENTS)} 个")
        print(f"测试输入：{INPUT_FILE}")
        print(f"结果文件：{OUTPUT_FILE}")
        return

    records = load_records()
    if OUTPUT_FILE.exists() and json.loads(OUTPUT_FILE.read_text(encoding="utf-8-sig")):
        raise SystemExit(f"结果文件已有内容，请先另存或移走，以免覆盖：{OUTPUT_FILE}")
    tokenizer, model, model_dir = load_model()
    results: list[Any] = []

    print(f"共读取 {len(records)} 条测试输入。", flush=True)
    for index, record in enumerate(records, start=1):
        record_id = record.get("record_id") or record.get("case_id") or f"record_{index:04d}"
        print(f"[{index}/{len(records)}] 正在生成：{record_id}", flush=True)
        try:
            raw_output = generate(tokenizer, model, record)
            parsed_output = extract_json(raw_output)
            output: Any = parsed_output if parsed_output is not None else raw_output
        except Exception as exc:
            print(f"第 {index} 条生成失败，已保存前 {len(results)} 条结果：{exc}", flush=True)
            raise

        # 只保存模型输出，列表顺序与测试输入一致。
        results.append(output)

        # 每生成一条就保存一次，避免 CPU 长时间运行中断后全部丢失。
        OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
        temporary = OUTPUT_FILE.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temporary.replace(OUTPUT_FILE)

    print(f"测试完成，结果已保存：{OUTPUT_FILE}", flush=True)
    print(f"使用模型：{model_dir}", flush=True)


if __name__ == "__main__":
    main()
