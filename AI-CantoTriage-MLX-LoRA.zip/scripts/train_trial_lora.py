"""Apple Silicon LoRA trial. Never writes to the LCMDC source directory.
Run: python3 scripts/train_trial_lora.py
"""
from __future__ import annotations
import argparse, ast, hashlib, json, os, platform, time
from pathlib import Path
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TOKENIZERS_PARALLELISM']='false'
ROOT=Path(__file__).resolve().parents[1]
import sys, site
DEPS=ROOT/'runtime/python_deps'
if DEPS.exists():
    site.addsitedir(str(DEPS))
    sys.path.insert(0,str(DEPS))

def dump(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    temp.replace(path)

def legacy_context():
    ns={'json':json}
    for node in ast.parse((ROOT/'scripts/evaluate_base_model_test.py').read_text()).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('DEPARTMENTS','SYSTEM_PROMPT') for t in node.targets):
            exec(compile(ast.Module(body=[node],type_ignores=[]),'legacy_prompt','exec'),ns)
    return ns['SYSTEM_PROMPT'],ns['DEPARTMENTS']

def source_hashes():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'LCMDC_训练数据_428条').rglob('*')) if p.is_file()}

def records(split):
    paths=list((ROOT/'LCMDC_训练数据_428条').glob(split+'*/总*/*.jsonl'))
    assert len(paths)==1,paths
    return [json.loads(l) for l in paths[0].read_text(encoding='utf-8-sig').splitlines() if l.strip()]

def messages(row, system):
    return [{'role':'system','content':system},{'role':'user','content':'请根据以下患者资料完成粤语文字导诊，并严格按照系统要求只输出 JSON：\n'+json.dumps(row['input'],ensure_ascii=False)}]

def parse(text):
    text=text.rsplit('</think>',1)[-1].strip()
    try:
        obj=json.loads(text)
        return obj if isinstance(obj,dict) else None
    except ValueError:
        for i,c in enumerate(text):
            if c=='{':
                try:
                    obj,_=json.JSONDecoder().raw_decode(text[i:])
                    if isinstance(obj,dict): return obj
                except ValueError: pass
    return None

def metrics(outputs, gold, departments):
    n=len(gold); exact=overlap=action=valid=legal=tp=fp=fn=0
    per={d:{'tp':0,'fp':0,'fn':0,'support':0} for d in departments}
    for pred,row in zip(outputs,gold):
        target=row['output']; g=set(target['建議科室'])
        pred=pred if isinstance(pred,dict) else {}
        ds=pred.get('建議科室'); p=set(ds) if isinstance(ds,list) and all(isinstance(x,str) for x in ds) else set()
        exact+=bool(p) and p==g; overlap+=bool(p&g)
        action+=pred.get('分流動作')==target['分流動作']
        valid+=bool(pred); legal+=bool(p) and p<=set(departments)
        tp+=len(p&g);fp+=len(p-g);fn+=len(g-p)
        for d in departments:
            per[d]['tp']+=int(d in p&g);per[d]['fp']+=int(d in p-g);per[d]['fn']+=int(d in g-p);per[d]['support']+=int(d in g)
    return {'n':n,'department_exact_match':exact/n,'department_any_match':overlap/n,'department_micro_f1':2*tp/max(1,2*tp+fp+fn),'action_accuracy':action/n,'parsed_json_object_rate':valid/n,'legal_department_rate':legal/n,'per_department':per}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--iters',type=int,default=281);ap.add_argument('--evaluate-only',action='store_true');ap.add_argument('--check',action='store_true');args=ap.parse_args()
    system,departments=legacy_context(); initial=source_hashes()
    splits={s:records(s) for s in ('训练','验证','测试')}
    assert [len(splits[s]) for s in ('训练','验证','测试')]==[281,48,99]
    historical_input=next((ROOT/'LCMDC_训练数据_428条').glob('测试*/输入*/*.jsonl'))
    historical_ids=[json.loads(line)['record_id'] for line in historical_input.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    assert historical_ids==[row['record_id'] for row in splits['测试']], 'Historical test order differs from gold'
    ids=[{r['record_id'] for r in rows} for rows in splits.values()]
    assert all(not ids[i]&ids[j] for i in range(3) for j in range(i))
    assert all(len(ids[i])==len(rows) for i,rows in enumerate(splits.values()))
    if args.check:
        print('Data counts, unique IDs and split separation verified. Source is read-only.');return
    import importlib.metadata as md
    import mlx.core as mx
    import mlx.optimizers as optim
    import numpy as np
    from mlx_lm import load, generate
    from mlx_lm.sample_utils import make_sampler
    from mlx_lm.tuner.trainer import TrainingArgs, train, evaluate, TrainingCallback
    from mlx_lm.tuner.utils import linear_to_lora_layers, load_adapters
    from mlx.utils import tree_flatten
    out=ROOT/'试微调'/'LoRA试验';out.mkdir(parents=True,exist_ok=True)
    adapter=out/'adapter';adapter.mkdir(exist_ok=True)
    model,tokenizer=load(str(ROOT/'导诊模型'))
    config={'base_model':'Qwen/Qwen3-1.7B','revision':'70d244cc86ccca08cf5af4e1e306ecf908b1ad5e','seed':42,'iters':args.iters,'batch_size':1,'learning_rate':1e-4,'num_layers':16,'fine_tune_type':'lora','lora_parameters':{'rank':8,'scale':16.0,'dropout':0.0},'max_new_tokens':1024,'temperature':0,'enable_thinking':False,'mask_prompt':True,'split_counts':{s:len(x) for s,x in splits.items()},'source_sha256':initial,'system_prompt':system,'platform':platform.platform(),'packages':{p:md.version(p) for p in ('mlx','mlx-lm','transformers','numpy')}}
    dump(out/'运行配置.json',config)
    def dataset(rows):
        data=[]
        for row in rows:
            msgs=messages(row,system)
            prefix=tokenizer.apply_chat_template(msgs,tokenize=True,add_generation_prompt=True,enable_thinking=False)
            full=tokenizer.apply_chat_template(msgs+[{'role':'assistant','content':json.dumps(row['output'],ensure_ascii=False)}],tokenize=True,enable_thinking=False)
            assert full[:len(prefix)]==prefix,'Chat template prefix mismatch'
            assert len(full)>len(prefix)
            data.append((full,len(prefix)))
        return data
    training=dataset(splits['训练']);validation=dataset(splits['验证'])
    maxlen=max(len(x[0]) for x in training+validation)
    config['max_seq_length']=((maxlen+31)//32)*32+1
    config['max_observed_tokens']=maxlen
    print('Token lengths and config:',config['max_seq_length'],config['iters'],flush=True)
    dump(out/'运行配置.json',config)
    if not args.evaluate_only:
        if (adapter/'adapters.safetensors').exists(): raise RuntimeError('Adapter already exists; use --evaluate-only or archive the previous experiment')
        np.random.seed(42);mx.random.seed(42)
        model.freeze();linear_to_lora_layers(model,16,config['lora_parameters'])
        dump(adapter/'adapter_config.json',config)
        class Callback(TrainingCallback):
            best=float('inf')
            def on_train_loss_report(self,info):
                print('TRAIN',json.dumps(info),flush=True)
                with (out/'训练指标.jsonl').open('a') as f:f.write(json.dumps({'type':'train',**info})+'\n')
            def on_val_loss_report(self,info):
                print('VALID',json.dumps(info),flush=True)
                with (out/'训练指标.jsonl').open('a') as f:f.write(json.dumps({'type':'validation',**info})+'\n')
                if info['val_loss']<self.best:
                    self.best=info['val_loss'];mx.save_safetensors(str(adapter/'best.safetensors'),dict(tree_flatten(model.trainable_parameters())))
                    dump(out/'最佳验证.json',info)
        cb=Callback()
        train(model,optim.AdamW(learning_rate=1e-4,weight_decay=0.01),training,validation,TrainingArgs(batch_size=1,iters=args.iters,val_batches=-1,steps_per_report=10,steps_per_eval=140,steps_per_save=args.iters,adapter_file=str(adapter/'last.safetensors'),max_seq_length=config['max_seq_length'],grad_checkpoint=True),training_callback=cb)
        final_loss=evaluate(model,validation,batch_size=1,num_batches=-1,max_seq_length=config['max_seq_length'])
        cb.on_val_loss_report({'iteration':args.iters,'val_loss':final_loss})
        (adapter/'adapters.safetensors').write_bytes((adapter/'best.safetensors').read_bytes())
        model.load_weights(str(adapter/'adapters.safetensors'),strict=False)
    else: load_adapters(model,str(adapter))
    model.eval();mx.clear_cache()
    result_file=out/'微调测试结果.json'; detail_file=out/'测试逐条记录.json'
    details=json.loads(detail_file.read_text()) if detail_file.exists() else []
    assert [x['record_id'] for x in details]==[r['record_id'] for r in splits['测试'][:len(details)]]
    results=[x['output'] for x in details]
    for i,row in enumerate(splits['测试'][len(details):],start=len(details)+1):
        prompt=tokenizer.apply_chat_template(messages(row,system),tokenize=False,add_generation_prompt=True,enable_thinking=False)
        start=time.time();raw=generate(model,tokenizer,prompt=prompt,max_tokens=1024,sampler=make_sampler(temp=0),verbose=False)
        parsed=parse(raw);output=parsed if parsed is not None else raw
        details.append({'record_id':row['record_id'],'raw_output':raw,'output':output,'seconds':time.time()-start})
        results.append(output);dump(detail_file,details);dump(result_file,results)
        print(f'TEST {i}/99 elapsed={time.time()-start:.1f}s',flush=True)
    historical=json.loads((ROOT/'试微调/对照组结果.json').read_text(encoding='utf-8-sig'));assert len(historical)==99
    base=metrics(historical,splits['测试'],departments);tuned=metrics(results,splits['测试'],departments)
    assert source_hashes()==initial,'LCMDC source changed during experiment'
    report={'baseline':base,'lora':tuned,'delta':{k:tuned[k]-base[k] for k in tuned if isinstance(tuned[k],float)},'baseline_provenance':'Existing 99 outputs, aligned by original test input order; historical logs identify Qwen3-1.7B. Different inference backend; not a fresh same-backend control.','source_unchanged':True,'limitations':['Small, imbalanced pilot dataset; validation/test do not cover all 15 departments.','Automatic department/action metrics do not measure clinical safety or Cantonese fluency.','No test examples used for training or checkpoint selection.']}
    dump(out/'准确率对比.json',report);print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
